package com.educacionit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.educacionit.auth.AuthResponse;
import com.educacionit.dto.LoginRequest;


@Controller
public class LoginController {
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private String baseUrl; // Es http://localhost:8080
	
	
	@GetMapping("/login")
	public String loginPage() {		
		return "login";
	}
	
	/*
	@PostMapping("/login")
	public String login(@ModelAttribute User user, Model model, 
			HttpServletRequest request) {		
	    String apiUrl = baseUrl + "/auth/login";
	    AuthResponse response = restTemplate.postForObject(apiUrl, user, AuthResponse.class);
	    
	    if (response != null && response.getToken() != null) {
	        request.getSession().setAttribute("token", response.getToken());
	        return "redirect:/";
	    } else {
	        model.addAttribute("error", "Authentication failed");
	        return "login";
	    }
	}
	 */
}
