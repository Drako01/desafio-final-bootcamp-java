package com.educacionit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig { //Front

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http        		
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(authRequest -> authRequest
                        .requestMatchers("/**","/css/**", "/js/**", "/login"
                        		, "/img/**", "/favicon.ico", "/fecha/*")
                        .permitAll()
                        /*
                        .requestMatchers("/**", "/productos/**", "/backend/**"
    	                		, "/categorias/**", "/carritos/**", 
    	                		"/items/**", "/usuarios/**", "/backend/productos/json"
    	                		).hasAnyRole("USER", "ADMIN")*/
    	                //.anyRequest().authenticated()
                )
                
                .formLogin(formLogin -> formLogin
                        .loginPage("/login")
                        .permitAll()
                )
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
