package com.educacionit.dto;

public class RolesDTO {

}
